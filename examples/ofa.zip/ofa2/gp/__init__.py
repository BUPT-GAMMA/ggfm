"""The ``gp`` package includes datasets and GNN models for
efficient graph learning.
"""

__version__ = "0.0.0"
