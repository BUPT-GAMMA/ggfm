"""gp extracts gnn logics from packages and allows customized
layers, which is particularly useful for fast prototyping.
gp also implements models in dgl and pytorch-geometrics.
gp is task-oriented with task predictors.
"""
